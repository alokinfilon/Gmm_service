
import React, { Component } from 'react';
import {
    View,
    StyleSheet,
    Dimensions,
    TouchableOpacity,
    Text,
    FlatList,
    ActivityIndicator,
    Platform,
    Image,
    SafeAreaView,
    StatusBar,
    ImageBackground,
    Modal,
    TouchableWithoutFeedback,
    ScrollView,
    KeyboardAvoidingView,
    split
} from 'react-native';
var width = Dimensions.get('window').width;
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-community/async-storage';
import Colors from '../../common/Colors';
import CustomButton from '../../components/CustomButton';
import Fonts from '../../common/Fonts';
import BackHeader from '../../components/BackHeader';
import { StackActions, NavigationActions } from 'react-navigation';
import API from '../../common/API';
import timeout from '../../common/Timeout';
import Loader from '../../common/Loader';
import * as NetInfo from '@react-native-community/netinfo';
import Geolocation from '@react-native-community/geolocation';
import ImagePicker from 'react-native-image-crop-picker';
import { RNCamera } from 'react-native-camera';
import ImageResizer from 'react-native-image-resizer';
import RNFetchBlob from 'rn-fetch-blob';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import Video from 'react-native-video';
 


import {check,request, PERMISSIONS,openSettings, RESULTS} from 'react-native-permissions';
var isImageFLat = [];
var ImageFlatlist = [] ;
var secondFlatlist = [] ;
var second = [];
var videoArray = [];
var VideoUrlArray = [];
var VideoFlatlist = [];
var newarray = []
var secoundArray = []
var isImageFLat = []
var VIDEOURLlink = 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'

export default class CompleteWorkDetail_Next extends Component {
    constructor(props) {
        second = []
        isImageFLat = []
        ImageFlatlist = []
        secondFlatlist = []
        videoArray = []
        VideoFlatlist = [];

        super(props);
        this.state = {
            loading: false,
            refresh: false,
            dataMass: false,
            src1: [],
            CameraModalVisible: false,
            modalVisible: false,
            modalVisible2: false,
            cambtn: true,
            videobtn:true,
            flesh: false,
            submit: true,
            modal: true,
            isRecording: false,
            mime:"",
            mimeType:"",
            NewLink:"",
            videobtn1:true,
              rate: 1,
              volume: 1,
              muted: false,
              resizeMode: 'contain',
              duration: 0.0,
              currentTime: 0.0,
              paused: true,
              TakeImage:[],
              favs:[]
  
        };
    }

    onLoad = (data) => {
        this.setState({ duration: data.duration });
      };
    
      onProgress = (data) => {
        this.setState({ currentTime: data.currentTime });
      };
    
      onEnd = () => {
        this.setState({ paused: true })
      };
    
      onAudioBecomingNoisy = () => {
        this.setState({ paused: true })
      };

    componentDidMount() {
       
        AsyncStorage.setItem('removeDigi', "1");
        AsyncStorage.getItem("one").then(one => {
           this.setState({ src1: JSON.parse(one) })
        })

        
        AsyncStorage.getItem("TakeImage").then((TakeImage) => {
            this.setState({ TakeImage:JSON.parse(TakeImage) })
            console.log("img" ,this.state.TakeImage)

         })

        //  AsyncStorage.removeItem("TakeImage").then((TakeImage) => {
        //     console.log("TakeImage" ,TakeImage)
        //  })

    }  
    


    isRemuve2 = (index  , item) => {
        
        var Temp = []
        // var isImageFLat = []

        this.state.TakeImage.splice(index, 1)

        AsyncStorage.removeItem('TakeImage').then((isImageFLat) => {
            console.log("isImageFLat" ,isImageFLat)
        })

         console.log("array" , this.state.TakeImage)
         this.setState({ refresh: !this.state.refresh })

         AsyncStorage.removeItem("TakeImage").then((TakeImage) => {
            console.log("TakeImage" ,TakeImage)
         })

         AsyncStorage.setItem('TakeImage',JSON.stringify(isImageFLat))
         
         

    }


    isRemuve = (index) => {
        ImageFlatlist.splice(index, 1)
        this.setState({ refresh: !this.state.refresh })
    }

    
    SetCameraModalVisible(visible) {
     this.setState({CameraModalVisible: visible, modalVisible: false, modalVisible2: false });
    }
    setModalVisible(visible) {

        this.setState({ modalVisible: visible, modal: true});
    }

    setModalVisible2(visible) {

        this.setState({ modalVisible2: visible, modal: false });
    }

    componentWillUnmount() {
        AsyncStorage.setItem('removeDigi', "0")   
    }
     
    getPermissions = () => {
        async function requestAll() {
     
            const locationStatus = Platform.select({
              android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
              ios: PERMISSIONS.IOS.LOCATION_ALWAYS
            });
            const photoLibrary = Platform.select({
              android: PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE,
              android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
              ios: PERMISSIONS.IOS.PHOTO_LIBRARY
            });
            const cameraStatus = Platform.select({
              android: PERMISSIONS.ANDROID.CAMERA,
              ios: PERMISSIONS.IOS.CAMERA
            });
            const isLocationStatus = await request(locationStatus);
            const isPhotoLibrary = await request(photoLibrary);
            const IsCameraStatus = await request(cameraStatus);
            
            return {isLocationStatus,isPhotoLibrary,IsCameraStatus};
          }     
           requestAll().then(statuses => console.log(statuses));  
     }
 
    Permissions= ()=> {
        const cameraStatus = Platform.select({
            android: PERMISSIONS.ANDROID.CAMERA,
            ios: PERMISSIONS.IOS.CAMERA
          });
        check(cameraStatus)
        .then(result => {
          switch (result) {
            case RESULTS.UNAVAILABLE:
                Toast.show("This feature is not available (on this device / in this context)", Toast.SHORT, Toast.BOTTOM);
                break;
            case RESULTS.DENIED:
                Toast.show("The permission has not been requested / is denied but requestable", Toast.SHORT, Toast.BOTTOM);
                this.getPermissions()
                 break;
            case RESULTS.GRANTED:
                this.setState({ modalVisible: false, modalVisible2: false});    
                this.SetCameraModalVisible(true);
                break;
            case RESULTS.BLOCKED: 
                this.setState({modalVisible:false,modalVisible2:false})
                setTimeout(() => {
                    Toast.show("The permission is Blocked and not requestable anymore", Toast.SHORT, Toast.BOTTOM);
                }, 100);               
                setTimeout(() => {
                    openSettings().catch(() => console.warn('cannot open settings'));
                }, 2000);           
                break;
          }
        })
        .catch(error => {
    console.log('errror',error);
          });
     }

    pickMultiple() {
            ImagePicker.openPicker({
                multiple: true,
                includeBase64: true,
                waitAnimationEnd: false,
                includeExif: true,
                loading: true,
                forceJpg: true,
                maxFiles: 10,
                compressImageQuality: 0.5,
                mediaType: '',
                mime:""
            }).then(images => {

                console.log("12341233",images);
                this.setState({mime:images[0].mime})
                var img =  this.state.mime
                var name = img.split('/',);
                console.log("1234",name);                       

               if(name[1] == 'mp4')
                {  
                for (let i = 0; i < images.length; i++) {
                     var obj = {
                         videourl:images[i].path,
                         base64:images[i].data,
                         type:name[1],
                         visible:true
                     }   
                     ImageFlatlist.push(obj);
                }
                console.log("ImageFlatlist",ImageFlatlist);
            
            }
            else {
                for (let i = 0; i < images.length; i++) {
                    var obj = {
                        base64:images[i].data,
                        type:name[1]
                    }   
                    ImageFlatlist.push(obj);
                   //  isImageFLat.push(obj)
               }
               console.log("ImageFlatlist",ImageFlatlist);
            }

                this.setState({
                    modalVisible: false, loading: false
                });
            }).catch(e => {
           
                this.setState({
                    modalVisible: false, loading: false
                });
                setTimeout(() => {
                    Toast.show(e.toString(), Toast.LONG, Toast.BOTTOM)
                }, 100);
                setTimeout(() => {
                    openSettings().catch(() => console.warn('cannot open settings'));
                }, 2000);
            }
            );
        }


    pickMultiple2() {

        // AsyncStorage.removeItem("TakeImage").then((TakeImage) => {
        //     console.log("TakeImage" ,TakeImage)
        //  })

            ImagePicker.openPicker({
                multiple: true,
                includeBase64: true,
                waitAnimationEnd: false,
                includeExif: true,
                loading: true,
                forceJpg: true,
                maxFiles: 10,
                compressImageQuality: 0.5,
                mediaType: '',
                mime:""
            }).then(images => {

                  console.log("SSS12341233",images);
                this.setState({mime:images[0].mime})
                var img =  this.state.mime
                var name = img.split('/',);
                console.log("SSSS1234",name);


                if(name[1] == 'mp4'){
                    for (let i = 0; i < images.length; i++) {
                        var obj = {
                            videourl:images[i].path ,
                            base64:images[i].data,
                            type:name[1],
                            visible:true
                        }   
                       
                        this.state.TakeImage.push(obj)
                   }
                   console.log("secondFlatlist1212",this.state.TakeImage);

                }
            else{
               

                for (let i = 0; i < images.length; i++) {
                     var obj = {
                        
                         type:name[1],
                         base64:images[i].data,
                     }   
                     this.state.TakeImage.push(obj)
                }
                console.log("secondFlatlist00000",this.state.TakeImage);
            }
           
                this.setState({
                    modalVisible2: false, loading: false
                });
            }).catch(e => {
           
                this.setState({
                    modalVisible: false, loading: false
                });
                setTimeout(() => {
                    Toast.show(e.toString(), Toast.LONG, Toast.BOTTOM)
                }, 100);
                setTimeout(() => {
                    openSettings().catch(() => console.warn('cannot open settings'));
                }, 2000);
            }
            );
        }

    saveSign = () => {

        this.setState({ loading: true, submit: false })

        Geolocation.getCurrentPosition(position => {
            const lastPosition = JSON.stringify(position);
            this.setState({ lastPosition });

            var lat = position.coords.latitude;
            var long = position.coords.longitude;



            if (isImageFLat.length < 1) {

                this.setState({ loading: false, submit: true });
                Toast.show('Please Select Report', Toast.SHORT, Toast.BOTTOM);
            }

            else {
                   
                this.offlineproceed(lat, long)
            }
        },
            (error) => {
                this.setState({ loading: false, submit: true });
                setTimeout(() => {


                    if (error.message == "No location provider available.") {

                        if (Platform.OS == "android") {

                            RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({ interval: 1000000, fastInterval: 50000 })
                                .then(data => {
                                    console.log(data);
                                    this.setState({ loading: true, submit: false },()=>{
                                        this.saveSign()
                                    })
                                   
                                }).catch(err => {
                                    console.log(err);

                                });
                        } else {
                            Toast.show("Please Turn on Your Location", Toast.SHORT, Toast.BOTTOM);
                        }

                    }
                   else if(error.message == "User denied access to location services."){
                  
                    Toast.show("Please Allow access to location services.", Toast.SHORT, Toast.BOTTOM);
                    setTimeout(() => {
                        openSettings().catch(() => console.warn('cannot open settings'));
                    }, 2000);
                  
                }
                    else {
                        Toast.show(error.message, Toast.SHORT, Toast.BOTTOM);
                    }
                }, 50)
                console.log('dd',error)
            },
            { enableHighAccuracy: false, timeout: 20000, maximumAge: 10000 }
        );
    }

    offlineproceed(lat, long) {


        this.setState({ loading: true, submit: false })


        console.log('if call');
        AsyncStorage.getItem("id").then(id => {
            AsyncStorage.getItem("token").then(token => {
                AsyncStorage.getItem("branch_id").then(branch_id => {

                    AsyncStorage.getItem("signature").then(signature => {
                        var Request = {
                            token: token,
                            id: id,
                            branch_id: branch_id,
                            signature: '',
                            lat: lat,
                            long: long,
                            first: this.state.src1,
                            third: {
                                image: ImageFlatlist,
                                report: this.state.TakeImage,
                            },

                            ig: signature
                        }

                        console.log(Request);
                        this.setState({ loading: false })

                        console.log("API",API.e_call_complete_offline);
                        console.log('Request', JSON.stringify(Request));
                        NetInfo.fetch().then(state => {
                            if (state.isConnected) {
                                timeout(
                                    15000,
                                    fetch(API.e_call_complete_offline, {
                                        method: 'POST',
                                        headers: {
                                            Accept: 'application/json',
                                            'Content-Type': 'application/json',
                                        },
                                        body: JSON.stringify(Request),
                                    })
                                        .then(res => {
                                            if (res.status == 200) {
                                                console.log(res);
                                                this.setState({ loading: false, loading1: false, submit: true });
                                                res.json().then(res => {
                                                    console.log('e_call_complete_offline:::  ', res);

                                                    if (res.status == 'success') {

                                                        AsyncStorage.removeItem('one');
                                                        AsyncStorage.removeItem('two');
                                                        AsyncStorage.removeItem('three');
                                                        AsyncStorage.removeItem('calltype');
                                                        AsyncStorage.removeItem('Local');
                                                        AsyncStorage.removeItem('TakeImage')



                                                        AsyncStorage.removeItem('UpdateSignature');
                                                        const resetAction = StackActions.reset({
                                                            index: 0,
                                                            actions: [
                                                                NavigationActions.navigate({
                                                                    routeName: 'Home',
                                                                }),
                                                            ],
                                                        });
                                                        this.props.navigation.dispatch(resetAction);



                                                    } else if (res.status == 'failed') {
                                                        AsyncStorage.removeItem('id');
                                                        AsyncStorage.removeItem('username');
                                                        AsyncStorage.removeItem('password');
                                                        this.setState({ loading: false, loading1: false, submit: true });
                                                        setTimeout(() => {
                                                            Toast.show(res.message, Toast.SHORT, Toast.BOTTOM);
                                                        }, 50);
                                                        const resetAction = StackActions.reset({
                                                            index: 0,
                                                            actions: [
                                                                NavigationActions.navigate({
                                                                    routeName: 'Login',
                                                                }),
                                                            ],
                                                        });
                                                        this.props.navigation.dispatch(resetAction);
                                                    } else {
                                                        this.setState({
                                                            loading: false,
                                                            loading1: false,
                                                            submit: true,
                                                            message: res.message,
                                                        });
                                                        setTimeout(() => {
                                                            Toast.show(res.message, Toast.SHORT, Toast.BOTTOM);
                                                        }, 50);
                                                    }
                                                });
                                            } else {
                                                AsyncStorage.removeItem('id');
                                                AsyncStorage.removeItem('username');
                                                AsyncStorage.removeItem('password');
                                                this.setState({ loading: false, loading1: false, submit: true });

                                                const resetAction = StackActions.reset({
                                                    index: 0,
                                                    actions: [
                                                        NavigationActions.navigate({ routeName: "Login" })
                                                    ]
                                                });
                                                this.props.navigation.dispatch(resetAction);

                                            }
                                        })
                                        .catch(e => {
                                            this.setState({ loading: false, loading1: false, submit: true });
                                            console.log(e);
                                            Toast.show(
                                                'Something went wrong...',
                                                Toast.SHORT,
                                                Toast.BOTTOM,
                                            );
                                        }),
                                ).catch(e => {
                                    console.log(e);
                                    this.setState({ loading: false, loading1: false, submit: true });
                                    Toast.show(
                                        'Please Check your internet connection',
                                        Toast.SHORT,
                                        Toast.BOTTOM,
                                    );
                                });
                            } else {
                                this.setState({ loading: false, loading1: false, submit: true });
                                Toast.show(
                                    'Please Check your internet connection',
                                    Toast.SHORT,
                                    Toast.BOTTOM,
                                );
                            }
                        });
                    })
                })
            })
        })


    }

   

 

   
    takeRecord= async function(){
        if (this.camera) {
            this.setState({isRecording:true});
            const options = { quality:RNCamera.Constants.VideoQuality["480p"],maxFileSize:(100*1024*1024), maxDuration: 60 };
            const data = await this.camera.recordAsync(options);
            console.log('takeRecord data', data);
            this.setState({modalVisible: false, modalVisible2: false , loading:true });
            this.SetCameraModalVisible(!this.state.CameraModalVisible);

                 var video1 =  data.uri
            var name11 = video1.split('.',);
            console.log("1234",name11);    

                RNFetchBlob.fs
            .readFile(data.uri, "base64")
          
            .then(data => {
                console.log("base64" , data);

                if (this.state.modal) {
                newarray.push(data)
                for(var i=0 ; i<newarray.length ; i++){
                    var object = {
                        videourl : video1,
                        visible : true ,
                        type: name11[2],
                        base64 : data
                    }
                }
                   ImageFlatlist.push(object)
                console.log("VideoFlatlist",ImageFlatlist); 
                this.setState({loading:false  }); 
            } else {
                secoundArray.push(data)
                for(var i=0 ; i<secoundArray.length ; i++){
                    var object = {
                        videourl : video1,
                        visible : true ,
                        type: name11[2],
                        base64 : data
                    }
                }
                this.state.TakeImage.push(object)
                console.log("VideoFlatlist000", this.state.TakeImage); 
                this.setState({loading:false  }); 
            }   
            });
              this.setState({
                modalVisible: false ,  modalVisible2: false  
            });
        }
    };
    
    stopRecord = () => {
        if (this.camera) {
            this.setState({isRecording:false});
            this.camera.stopRecording()
            this.setState({modalVisible: false, modalVisible2: false , loading:false });
            // this.SetCameraModalVisible(!this.state.CameraModalVisible);
        }
    }
  
 

    render() {
        const { navigate } = this.props.navigation;
        return (
            <View style={{ flex: 1 }}>

               

                    <Modal
                        transparent={true}
                        animationType={"fade"}
                        visible={this.state.CameraModalVisible}
                        onRequestClose={() => { }}
                    >
                            <SafeAreaView style={{ flex: 1, backgroundColor: Colors.primary }}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'column'
                        }}>

                            <StatusBar
                                hidden={false}
                                barStyle="dark-content"
                                backgroundColor={Colors.primary}
                            />
                            <BackHeader
                                backIcon={require('../../images/Left_arrow.png')}
                                pageTitle="Images/Video"
                                back={() => {

                                    this.SetCameraModalVisible(!this.state.CameraModalVisible);
                                }}
                            />

                            <RNCamera
                                ref={ref => {
                                    this.camera = ref;
                                }}
                                style={styles.preview}
                                type={RNCamera.Constants.Type.back}
                                flashMode={RNCamera.Constants.FlashMode.off}
                                androidCameraPermissionOptions={{
                                    title: 'Permission to use camera',
                                    message: 'We need your permission to use your camera',
                                    buttonPositive: 'Ok',
                                    buttonNegative: 'Cancel',
                                }}
                            />

                            <View style={{flexDirection:'row' , justifyContent:'space-around'}}>
                            <View>
                                {this.state.cambtn ?
                                    <View style={{ position: 'absolute', bottom: 10, alignSelf: 'center', marginTop: 10 }}>
                                        <TouchableOpacity style={{ height: 60, width: 60, backgroundColor: Colors.primary, justifyContent: 'center', 
                                        alignItems: 'center', borderRadius: 30 }} onPress={this.takePicture.bind(this)}>
                                            <ImageBackground
                                                resizeMode="contain"
                                                style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                                source={require('../../images/fill.png')}>
                                                <Image style={{ height: 25, width: 25, tintColor: Colors.primary }} 
                                                source={require('../../images/photo-camera.png')} />
                                            </ImageBackground>
                                        </TouchableOpacity>
                                    </View>
                                     : null} 
                            </View>

                              <View>
                                
                                    <View style={{ position: 'absolute', bottom: 10, alignSelf: 'center', marginTop: 10 }}>

                                        
                                    {this.state.isRecording ?
                                        <TouchableOpacity style={{ height: 60, width: 60, backgroundColor: Colors.primary, justifyContent: 'center', 
                                        alignItems: 'center', borderRadius: 30 }} 
                                        onPress={this.stopRecord.bind(this)}
                                        >
                                            <ImageBackground
                                                resizeMode="contain"
                                                style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                                source={require('../../images/fill.png')}>
                                                    
                                                    <Image
                                                   style={{ height: 25, width: 25 }}
                                                    source={require('../../images/stoprecording.png')}/>
                                                      
                                                        {/* <Text style={styles.flipText}> stop </Text> */}
                                                       
                                            </ImageBackground>
                                           
                                             {/* <VideoRecorder ref={(ref) => { this.videoRecorder = ref; }} /> */}
                                             
                                          
                                        </TouchableOpacity>
                                        :  <TouchableOpacity style={{ height: 60, width: 60, backgroundColor: Colors.primary, justifyContent: 'center', 
                                        alignItems: 'center', borderRadius: 30 }} 
                                        onPress={this.takeRecord.bind(this)}
                                        >
                                            <ImageBackground
                                                resizeMode="contain"
                                                style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                                source={require('../../images/fill.png')}>
                                                    
                                                    
                                                      
                                                    <Image
                                                   style={{ height: 25, width: 25, tintColor: Colors.primary }}
                                                    source={require('../../images/video.png')}/>
                                                       
                                            </ImageBackground>
                                           
                                             {/* <VideoRecorder ref={(ref) => { this.videoRecorder = ref; }} /> */}
                                             
                                          
                                        </TouchableOpacity> }
                                      

                                        {/* <TouchableOpacity 
                                        onPress={this.stopRecordingVideo}
                                        style={{height:20  , width: 20 , backgroundColor:Colors.primary}}/>  */}
                                    </View>

                                 

                                
                                     
                            </View>  
                            </View>
                           

                        </View>
                        </SafeAreaView>
                    </Modal>
                 
                    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.primary }}>
                        <StatusBar
                            hidden={false}
                            barStyle="dark-content"
                            backgroundColor={Colors.primary}
                        />
                        <BackHeader
                            backIcon={require('../../images/Left_arrow.png')}
                            pageTitle="Service Report"
                            back={() => {
                                this.props.navigation.goBack();
                            }}
                        />
                        <Loader loading={this.state.loading} />
                        <KeyboardAvoidingView
                            behavior={Platform.OS == 'ios' ? 'padding' : null}
                            style={{ flex: 1, backgroundColor: Colors.white }}>
                            <ScrollView
                                style={{ flex: 1, backgroundColor: '#f1f1f1' }}
                                showsVerticalScrollIndicator={false}>
                                <View style={styles.container} refresh={this.state.refresh}>
                                    <View
                                        style={{
                                            flex: 1,
                                            marginBottom: 10,
                                            flexDirection: 'column',
                                            backgroundColor: Colors.white,
                                            borderWidth: 1,
                                            paddingBottom: 10,
                                            borderTopLeftRadius: 5,
                                            // borderLeftWidth: 6,
                                            // borderLeftColor: Colors.medium_gray,
                                            borderBottomLeftRadius: 5,
                                            borderColor: Colors.light_gray,
                                            shadowOffset: { width: 0, height: 5 },
                                            shadowColor: Colors.medium_gray,
                                            shadowOpacity: 0.8,
                                            elevation: 2,
                                        }}>
                                        <View
                                            style={{
                                                flex: 1,
                                                width: '100%',
                                                overflow: 'hidden',
                                                alignSelf: 'center'
                                            }}>

                                            <View style={{ flexDirection: 'row', width: '100%', marginTop: 10 }}>
                                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>

                                                    <Text
                                                        style={{
                                                            textAlign: 'left',
                                                            fontSize: 16,

                                                            // backgroundColor: Colors.light_gray,
                                                            fontFamily: Fonts.medium,
                                                            color: Colors.primary,
                                                        }}>
                                                        Capture Report
                                        </Text>
                                                </View>

                                                <TouchableOpacity onPress={() => this.setModalVisible(true)} style={{ alignSelf: "center", flexDirection: "column", marginRight: 12 }}>

                                                    <View style={{ height: 70, width: 70, alignItems: "center", justifyContent: "center", borderRadius: 10, borderColor: Colors.light_gray, backgroundColor: Colors.light_gray, borderWidth: 1 }}>
                                                        <ImageBackground
                                                            resizeMode="contain"
                                                            style={{ height: 60, width: 60, marginRight: 0, alignItems: 'center', justifyContent: 'center', }}
                                                            source={require('../../images/fill.png')}>
                                                            <Image style={{ height: 32, width: 32, tintColor: Colors.primary }} source={require('../../images/add.png')} />
                                                        </ImageBackground></View>
                                                </TouchableOpacity>

                                            </View>
                                        </View>
                                    </View>
                                     {ImageFlatlist.length > 0 ?  
                                    <View
                                        style={{
                                            flex: 1,
                                            marginBottom: 10,
                                            flexDirection: 'column',
                                            backgroundColor: Colors.white,
                                            borderWidth: 1,
                                            paddingBottom: 10,
                                            borderTopLeftRadius: 5,
                                            // borderLeftWidth: 6,
                                            // borderLeftColor: Colors.medium_gray,
                                            borderBottomLeftRadius: 5,
                                            borderColor: Colors.light_gray,
                                            shadowOffset: { width: 0, height: 5 },
                                            shadowColor: Colors.medium_gray,
                                            shadowOpacity: 0.8,
                                            elevation: 2, margin: 8
                                        }}>

                                        <View style={{ flex: 1 }}>

                                            <FlatList
                                                horizontal
                                                extraData={this.state.refresh}
                                                showsHorizontalScrollIndicator={false}
                                                data={
                                                    // VideoFlatlist
                                                    ImageFlatlist
                                                    // isImageFLat 

                                                }
                                                keyExtractor={(item, index) => index.toString()}

                                                renderItem={({ item, index }) => (

                                                    <View style={{ flex: 1, margin: 5 }}>
                                                        {item != "" ?
                                                            <View
                                                                style={{
                                                                    flexDirection: "row",
                                                                    flex: 1,
                                                                    // paddingLeft: 10,
                                                                    // marginVertical: 10,
                                                                    //alignItems: "center"
                                                                }}
                                                            >
                                                              
                                                                 { item.type == 'mp4' ?   
                                                                   <View>
                                                                   <Video
                                                                //    source={item.dataurl}
                                                                    //  source= {{ uri:"file:///data/user/0/com." + item.dataurl}}
                                                                    source={{ uri: item.videourl }}
                                                                 
                                                                   ref={(ref) => {
                                                                     this.player = ref
                                                                   }}
                                                                   resizeMode={"cover"}
                                                                   repeat={false}
                                                                   paused={item.visible}
                                                                   onLoad={this.onLoad}
                                                                   onProgress={this.onProgress}
                                                                   onEnd={this.onEnd}
                                                                   // onBuffer={console.log('buffer')}
                                                                   // onError={console.log('olnerror')}      
                                                                   style={{
                                                                     height: 250,
                                                                     width: 250,
                                                                     backgroundColor: 'white',
                                             
                                                                     borderRadius: 10
                                                                   }}
                                                                 />
                                             
                                                                 <TouchableOpacity
                                                                   onPress={() => {
                                                                     item.visible = !item.visible
                                                                     console.log(index);
                                                                     this.setState({ refresh: !this.state.refresh })
                                                                     console.log(ImageFlatlist);
                                                                   }
                                                                   }
                                                                   style={{ position: 'absolute', bottom: 15, right: 15 }}>
                                             
                                                                { item.visible ? 
                                                                     <Image
                                                                     style={{ height: 30, width: 30, tintColor: 'white' }}
                                                                     source={require('../../images/play_circle.png')} />
                                                                     :
                                                                     <Image
                                                                     style={{ height: 25, width: 25, tintColor: 'white' }}
                                                                     source={require('../../images/pause_icon.png')}/>
                                                                    }
                                             
                                                                 </TouchableOpacity>
                                             
                                                               </View>
                                                                                                          
                                                                   :   
                                                              <Image
                                                                    style={{
                                                                        height: 250,
                                                                        width: 250,
                                                                        backgroundColor: Colors.light_gray,

                                                                        borderRadius: 10
                                                                    }}
                                                                    source={{ uri: "data:image/png;base64," + item.base64 }}
                                                                />  
                                                               }  
 
                                                                <TouchableOpacity style={{ height: 35, width: 25, marginLeft: -12, marginTop: 0, }} onPress={() => this.isRemuve(index)}>
                                                                    <Image style={{ height: 22, width: 22 }} source={require('../../images/remove.png')} />
                                                                </TouchableOpacity>

                                                            </View>
                                                            : null}
                                                    </View>
                                                )}
                                            />



                                        </View>
                                    </View>
                                      : null } 
                                    <View
                                        style={{
                                            flex: 1,
                                            marginBottom: 10,
                                            flexDirection: 'column',
                                            backgroundColor: Colors.white,
                                            borderWidth: 1,
                                            paddingBottom: 10,
                                            borderTopLeftRadius: 5,
                                            // borderLeftWidth: 6,
                                            // borderLeftColor: Colors.medium_gray,
                                            borderBottomLeftRadius: 5,
                                            borderColor: Colors.light_gray,
                                            shadowOffset: { width: 0, height: 5 },
                                            shadowColor: Colors.medium_gray,
                                            shadowOpacity: 0.8,
                                            elevation: 2,
                                        }}>
                                        <View
                                            style={{
                                                flex: 1,
                                                width: '100%',
                                                overflow: 'hidden',
                                                alignSelf: 'center'
                                            }}>
                                            <View style={{ flexDirection: 'row', width: '100%', marginTop: 10 }}>
                                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>

                                                    <Text
                                                        style={{
                                                            textAlign: 'left',
                                                            fontSize: 16,

                                                            // backgroundColor: Colors.light_gray,
                                                            fontFamily: Fonts.medium,
                                                            color: Colors.primary,
                                                        }}>
                                                        Capture Attachment
                                        </Text>
                                                </View>

                                                <TouchableOpacity onPress={() => this.setModalVisible2(true)} style={{ alignSelf: "center", flexDirection: "column", marginRight: 12 }}>

                                                    <View style={{ height: 70, width: 70, alignItems: "center", justifyContent: "center", borderRadius: 10, borderColor: Colors.light_gray, backgroundColor: Colors.light_gray, borderWidth: 1 }}>
                                                        <ImageBackground
                                                            resizeMode="contain"
                                                            style={{ height: 60, width: 60, marginRight: 0, alignItems: 'center', justifyContent: 'center', }}
                                                            source={require('../../images/fill.png')}>
                                                            <Image style={{ height: 32, width: 32, tintColor: Colors.primary }} source={require('../../images/add.png')} />
                                                        </ImageBackground></View>
                                                </TouchableOpacity>

                                            </View>

                                        </View>
                                    </View>

                                {/* {this.state.TakeImage.length > 0 ?  */}
                                    <View
                                        style={{
                                            flex: 1,
                                            marginBottom: 10,
                                            flexDirection: 'column',
                                            backgroundColor: Colors.white,
                                            borderWidth: 1,
                                            paddingBottom: 10,
                                            borderTopLeftRadius: 5,
                                            // borderLeftWidth: 6,
                                            // borderLeftColor: Colors.medium_gray,
                                            borderBottomLeftRadius: 5,
                                            borderColor: Colors.light_gray,
                                            shadowOffset: { width: 0, height: 5 },
                                            shadowColor: Colors.medium_gray,
                                            shadowOpacity: 0.8,
                                            elevation: 2, margin: 8
                                        }}>

                                        <View style={{ flex: 1 }}>

                                            <FlatList
                                                horizontal
                                                extraData={this.state.refresh}
                                                showsHorizontalScrollIndicator={false}
                                                data={
                                                    this.state.TakeImage
                                                    // secondFlatlist
                                                    // second
                                                }
                                                keyExtractor={(item, index) => index.toString()}
                                                renderItem={({ item, index }) => (
                                                    <View style={{ flex: 1, margin: 5 }}>

                                                        <View
                                                            style={{
                                                                flexDirection: "row",
                                                                flex: 1,
                                                                // paddingLeft: 10,
                                                                // marginVertical: 10,
                                                                //alignItems: "center"
                                                            }}
                                                        >

                                                            { item.type == 'mp4' ?   
                                                                   <View>
                                                                   <Video
                                                                //    source={item.dataurl}
                                                                    //  source= {{ uri:"file:///data/user/0/com." + item.dataurl}}
                                                                    source={{ uri: item.videourl }}
                                                                 
                                                                   ref={(ref) => {
                                                                     this.player = ref
                                                                   }}
                                                                   resizeMode={"cover"}
                                                                   repeat={false}
                                                                   paused={item.visible}
                                                                   onLoad={this.onLoad}
                                                                   onProgress={this.onProgress}
                                                                   onEnd={this.onEnd}
                                                                   // onBuffer={console.log('buffer')}
                                                                   // onError={console.log('olnerror')}      
                                                                   style={{
                                                                     height: 250,
                                                                     width: 250,
                                                                     backgroundColor: 'white',
                                             
                                                                     borderRadius: 10
                                                                   }}
                                                                 />
                                             
                                                                 <TouchableOpacity
                                                                   onPress={() => {
                                                                     item.visible = !item.visible
                                                                     console.log(index);
                                                                     this.setState({ refresh: !this.state.refresh })
                                                                     console.log(this.state.TakeImage);
                                                                   }
                                                                   }
                                                                   style={{ position:'absolute',bottom:15, right: 15 }}>
                                             
                                                                    
                                                                      { item.visible ? 
                                                                     <Image
                                                                     style={{ height: 30, width: 30, tintColor: 'white' }}
                                                                     source={require('../../images/play_circle.png')} />
                                                                     :
                                                                     <Image
                                                                     style={{ height: 25, width: 25, tintColor: 'white' }}
                                                                     source={require('../../images/pause_icon.png')}/>
                                                                    }
                                                                     
                                             
                                                                 </TouchableOpacity>
                                             
                                                               </View>
                                                                                                          
                                                                   :   

                                                            <Image
                                                                style={{
                                                                    height: 250,
                                                                    width: 250,
                                                                    backgroundColor: Colors.light_gray,

                                                                    borderRadius: 10
                                                                }}
                                                                source={{ uri: "data:image/png;base64," + item.base64 }}
                                                            />
                                                }
                                                            {
                                                                //  </TouchableOpacity>
                                                            }
                                                            <TouchableOpacity 
                                                            style={{ height: 35, width: 25, marginLeft: -12, marginTop: 0, }} 
                                                            onPress={() => this.isRemuve2(index , item)}>
                                                                <Image style={{ height: 22, width: 22 }} source={require('../../images/remove.png')} />
                                                            </TouchableOpacity>

                                                        </View>

                                                    </View>
                                                )}
                                            />
                                        </View>
                  
                                    </View>
                                      {/* : null}   */}

                                    <CustomButton
                                        iconName={require('../../images/right.png')}
                                        name="End Work"
                                        onPress={() => {

                                            this.state.submit ? this.saveSign() : null
                                        }}
                                    />

 {/* <TouchableOpacity
 onPress={() => this.props.navigation.navigate('test1')}
 >
     <Text>open </Text>
 </TouchableOpacity> */}


                                    <Modal
                                        transparent={true}
                                        animationType={"fade"}
                                        visible={this.state.modalVisible}
                                        onRequestClose={() => { }}
                                    >
                                        <TouchableOpacity
                                            style={{
                                                flex: 1,
                                                justifyContent: "center",
                                                alignItems: "center",
                                                backgroundColor: "rgba(0, 0, 0, 0.6)"
                                            }}
                                            activeOpacity={1}
                                            onPressOut={() => {
                                                this.setModalVisible(!this.state.modalVisible);
                                            }}
                                        >
                                            <View style={styles.ModalInsideView}>
                                         
                                            <TouchableWithoutFeedback onPress={() =>{this.Permissions() }}>

                                                    <View
                                                        style={{
                                                            flex: 1,
                                                            flexDirection: "column",
                                                            alignItems: "center",
                                                            justifyContent: "center"
                                                        }}
                                                    >
                                                        <Image
                                                            source={require("../../images/photo-camera.png")}
                                                            style={{ tintColor: Colors.black, height: 40, width: 40 }}
                                                        />
                                                        <Text style={{ paddingTop: 10, color: Colors.black }}>
                                                            Open Camera
                        </Text>
                                                    </View>
                                                </TouchableWithoutFeedback>
                                                <View
                                                    style={{
                                                        width: 1,
                                                        backgroundColor: Colors.colorPrimary,
                                                        marginVertical: 35
                                                    }}
                                                />
                                                <TouchableWithoutFeedback onPress={this.pickMultiple.bind(this)}>
                                                    <View
                                                        style={{
                                                            flex: 1,
                                                            flexDirection: "column",
                                                            alignItems: "center",
                                                            justifyContent: "center"
                                                        }}
                                                    >
                                                        <Image
                                                            source={require("../../images/gallery.png")}
                                                            style={{ tintColor: Colors.black, height: 40, width: 40 }}
                                                        />
                                                        <Text style={{ paddingTop: 10, color: Colors.black }}>
                                                            Open Gallery
                                              </Text>
                                                    </View>
                                                </TouchableWithoutFeedback>
                                            </View>
                                        </TouchableOpacity>
                                    </Modal>


                                    <Modal
                                        transparent={true}
                                        animationType={"fade"}
                                        visible={this.state.modalVisible2}
                                        onRequestClose={() => { }}
                                    >
                                        <TouchableOpacity
                                            style={{
                                                flex: 1,
                                                justifyContent: "center",
                                                alignItems: "center",
                                                backgroundColor: "rgba(0, 0, 0, 0.6)"
                                            }}
                                            activeOpacity={1}
                                            onPressOut={() => {
                                                this.setModalVisible2(!this.state.modalVisible2);
                                            }}
                                        >
                                            <View style={styles.ModalInsideView}>
                                                
                                            <TouchableWithoutFeedback onPress={() =>{this.Permissions() }}>

                                                    <View
                                                        style={{
                                                            flex: 1,
                                                            flexDirection: "column",
                                                            alignItems: "center",
                                                            justifyContent: "center"
                                                        }}
                                                    >
                                                        <Image
                                                            source={require("../../images/photo-camera.png")}
                                                            style={{ tintColor: Colors.black, height: 40, width: 40 }}
                                                        />
                                                        <Text style={{ paddingTop: 10, color: Colors.black }}>
                                                            Open Camera
                                               </Text>
                                                    </View>
                                                </TouchableWithoutFeedback>
                                                <View
                                                    style={{
                                                        width: 1,
                                                        backgroundColor: Colors.colorPrimary,
                                                        marginVertical: 35
                                                    }}
                                                />
                                                <TouchableWithoutFeedback onPress={this.pickMultiple2.bind(this)}>
                                                    <View
                                                        style={{
                                                            flex: 1,
                                                            flexDirection: "column",
                                                            alignItems: "center",
                                                            justifyContent: "center"
                                                        }}
                                                    >
                                                        <Image
                                                            source={require("../../images/gallery.png")}
                                                            style={{ tintColor: Colors.black, height: 40, width: 40 }}
                                                        />
                                                        <Text style={{ paddingTop: 10, color: Colors.black }}>
                                                            Open Gallery
                        </Text>
                                                    </View>
                                                </TouchableWithoutFeedback>
                                            </View>
                                        </TouchableOpacity>
                                    </Modal>
                                </View>
                            </ScrollView>
                        </KeyboardAvoidingView>
                    </SafeAreaView>   
            </View>
        );
    }
    takePicture = async () => {
        this.setState({ cambtn:false})
        if (this.camera) {
            const options = { quality: 0.5 };
            const data = await this.camera.takePictureAsync(options);
            console.log("data", data);
             
            var imgPath =  data.uri
            var nameImage = imgPath.split('.',);
            console.log("1234",nameImage);        

            this.setState({modalVisible: false, modalVisible2: false,cambtn:false});
            this.SetCameraModalVisible(!this.state.CameraModalVisible);
            ImageResizer.createResizedImage(data.uri, 400, 300, 'JPEG', 100)
                .then(response => {
                    console.log("response",response.path)

                    RNFetchBlob.fs
                        .readFile(response.path, "base64")

                        .then(data => {
                          console.log('data', data);

                            if (this.state.modal) {
                                isImageFLat.push(data)

                                for(var i=0 ; i<= isImageFLat.length;i++){
                                      var obj = {
                                          base64:data,
                                          type:nameImage[2]
                                      }
                                 }
                                 ImageFlatlist.push(obj)
                                 console.log("ImageFlatlist",ImageFlatlist)
                            } else {
                                second.push(data)
                                for(var j=0 ; j<= second.length;j++){
                                    var obj = {
                                        base64:data,
                                        type:nameImage[2]
                                    }
                               }
                                this.state.TakeImage.push(obj)
                               console.log("secondFlatlist99",this.state.TakeImage)
                            }

                           
                            this.setState({ modalVisible: false, modalVisible2: false,cambtn:true});           
                        })
                        .catch(err => {
                            this.SetCameraModalVisible(!this.state.CameraModalVisible);
                            Toast.show(err.toString(), Toast.SHORT, Toast.BOTTOM);
                            this.setState({
                                modalVisible: false, modalVisible2: false,cambtn:true
                            });
                             
                        });
                })
                .catch(err => {
                    this.SetCameraModalVisible(!this.state.CameraModalVisible);
                    Toast.show(err.toString(), Toast.SHORT, Toast.BOTTOM);
                    this.setState({
                        modalVisible: false, modalVisible2: false,cambtn:true
                    });
                });         
        }
    }


    // takeVideo = async function() {
    //     if (this.camera) {
    //       try {
    //         const promise = this.camera.recordAsync(this.state.recordOptions);
    
    //         if (promise) {
    //           this.setState({ isRecording: true });
    //           const data = await promise;
    //           console.log('vvvvvvvv' , data);
    //           this.setState({ isRecording: false });
    //           console.log('takeVideo', data);
    //         }
    //       } catch (e) {
    //         console.log(e);
    //       }
    //     }
    //   };


}
const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        padding: 10,
        //  margin: 10,
        backgroundColor: '#f1f1f1',
    },
    textInput: {
        marginTop: 2,
        paddingVertical: Platform.OS == 'ios' ? 6 : 6,
        fontSize: 16,
        flex: 1,
        fontFamily: Fonts.medium,
        paddingHorizontal: 5,
    },
    label: {
        padding: 2,
        fontFamily: Fonts.regular,
        fontSize: 14,
        color: Colors.dark_gray,
        width: width * 0.3,
        paddingLeft: 15,
    },
    ModalInsideView: {
        flexDirection: 'row',

        backgroundColor: "#fff",
        height: 140,
        width: '85%',
        borderRadius: 3,
        borderWidth: 1,
        borderColor: '#fff'

    },
    preview: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
});
