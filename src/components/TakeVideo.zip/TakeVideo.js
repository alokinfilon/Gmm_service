
import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Image,
    StyleSheet,
    ImageBackground
} from 'react-native';
import ImageResizer from 'react-native-image-resizer';
import RNFetchBlob from 'rn-fetch-blob';
import { RNCamera } from 'react-native-camera';
import Toast from 'react-native-simple-toast';
import Colors from '../common/Colors';
import BackHeader from '../components/BackHeader';
import AsyncStorage from '@react-native-community/async-storage';
var isImageFLat = [];
var Time

var a = 500;
var b = 500;
export default class TakeVideo extends Component {
    constructor(props) {
        super(props);
        this.state = {

            refresh: false,
            CameraModalVisible: false,

            recording:false,
             save:false,
            flesh: false,
            retake: true,
            modal: true,
            cambtn:true
        }
    }

    componentDidMount() {
 
        // isImageFLat = []
       
        this.takePicture.bind(this)
    }

    render() {
        const { navigate } = this.props.navigation;
        return (

            <View style={{
                flex: 1,
                flexDirection: 'column'
            }}>
                <BackHeader
                    backIcon={require('../images/Left_arrow.png')}
                    pageTitle="Images/Video"
                    back={() => {
                        this.props.navigation.goBack();

                    }}
                />

                <RNCamera
                    ref={ref => {
                        this.camera = ref;
                    }}
                    style={styles.preview}
                    type={RNCamera.Constants.Type.back}
                    flashMode={RNCamera.Constants.FlashMode.off}
                    androidCameraPermissionOptions={{
                        title: 'Permission to use camera',
                        message: 'We need your permission to use your camera',
                        buttonPositive: 'Ok',
                        buttonNegative: 'Cancel',
                    }}
                />


                <View>



                    <View style={{ position: 'absolute', bottom: 10, alignSelf: 'center', marginTop: 10, width: '80%', justifyContent: 'space-between', flexDirection: 'row' }}>

                        <View style={{}}>
                            {this.state.cambtn ? 
                            <TouchableOpacity style={{
                                height: 60, width: 60, backgroundColor: Colors.primary, justifyContent: 'center',
                                alignItems: 'center', borderRadius: 30
                            }} onPress={this.takePicture.bind(this)}>
                                <ImageBackground
                                    resizeMode="contain"
                                    style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                    source={require('../images/fill.png')}>
                                    <Image style={{ height: 25, width: 25, tintColor: Colors.primary }}
                                        source={require('../images/photo-camera.png')} />
                                </ImageBackground>
                            </TouchableOpacity>
                            :null}
                        </View>

                        {/* {
                                    this.state.retake ? */}
                     
                            <TouchableOpacity style={{
                                height: 60, width: 60, backgroundColor: Colors.primary, justifyContent: 'center',
                                alignItems: 'center', borderRadius: 30
                            }} onPress={() => {
                                this.setState({ VideoPlay: !this.state.VideoPlay }, () => {
                                    this.state.VideoPlay ? this.startVideo() : this.stopVideo()

                                })
                            }}
                        >
                                
                                {this.state.VideoPlay ? 
                                
                                <ImageBackground
                                    resizeMode="contain"
                                    style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                    source={require('../images/fill.png')}>
                                          <Image
                                                   style={{ height: 25, width: 25 }}
                                                    source={require('../images/stoprecording.png')}/>
                                </ImageBackground>
                                
                                :
                                
                                <ImageBackground
                                resizeMode="contain"
                                style={{ height: 50, width: 50, alignItems: 'center', justifyContent: 'center', }}
                                source={require('../images/fill.png')}>
                              <Image
                                                   style={{ height: 25, width: 25  , tintColor: Colors.primary  }}
                                                    source={require('../images/video.png')}/>
                            </ImageBackground>
    }
                                   

                            </TouchableOpacity>
                            {/* <View style={{flexDirection:'row',justifyContent:'space-around'}}>

                           
                           <TouchableOpacity onPress={()=>{
                               this.save()
                           }}>
                                <Image style={{ height: 50, width: 50, tintColor: Colors.primary }}
                             source={{ uri: 'https://pngimage.net/wp-content/uploads/2018/06/right-sign-icon-png-2.png' }} />
                 
                           </TouchableOpacity>


                           <TouchableOpacity onPress={()=>{
                               this.remuve()
                           }}>
                           <Image style={{ height: 50, width: 50, tintColor: Colors.primary,marginLeft:8 }}
                                                      source={{ uri: 'https://cdn1.iconfinder.com/data/icons/material-design-2/32/cross-512.png' }} />
                                          
                                                    </TouchableOpacity>
                                                  </View>
                     } */}
     
                </View>

                    </View>
                </View>
        )
    }
     Time= ()=>{

                    // console.log('Time',Time,'this.state.Time',this.state.Time,"Time",min+":"+sec);

                    // this.setState({Time: this.state.Time + 1});
                    //   var min=Math.floor(this.state.Time/60)
                    //   var sec=Math.floor(this.state.Time-min*60)

                    //   this.setState({showTime:min+":"+sec})
                }

// save =() =>{
//     this.camera.stopRecording()

//     this.props.navigation.goBack();
// }

//  remuve = () =>{
   
//       this.camera.resumePreview()
//      this.setState({retake:true,recording:true})
     
//  }

     startVideo = async () => {

            isImageFLat = []

        if (this.camera && !this.state.recording) {
            console.log('ccccccc');
                    //  Time = setInterval(() => { this.Time()}, 100);
                    // need to do this in order to avoid race conditions
                    this.state.recording = true;
         var date = new Date();
          const options = {
            path: "/storage/emulated/0/DCIM/Camera/"+Math.floor(date.getTime()+ date.getSeconds() / 2)+".mp4",
            quality: '480p',
            maxDuration: 60,
            maxFileSize: 100 * 1024 * 1024
           };

          this.setState({recording: true, elapsed: -1}, async () => {

                    let result = null;
            try {
                    result = await this.camera.recordAsync(options);
                    
                        console.log("result" , result);
                        RNFetchBlob.fs
                        .readFile(result.uri, "base64")
                      
                        .then(data => {
                            console.log("base64" , data);
                            var obj={
                                type:'mp4',
                                videourl:result.uri,
                                base64:data
                        }
                         isImageFLat.push(obj)
                         AsyncStorage.setItem('TakeImage',JSON.stringify(isImageFLat))
                         console.log('isImageFLat',isImageFLat);
                        })

                

           

             
            }
            catch(err){
                    console.warn("VIDEO RECORD FAIL", err.message, err);

                    Toast.show(err.message.toString(), Toast.LONG, Toast.BOTTOM)
             
            }



            // give time for the camera to recover
            setTimeout(()=>{
                    this.setState({ recording: false });
            }, 500);
          });

        }
      }

      stopVideo = () => {

        if(this.camera && this.state.recording){
                    // clearInterval(Time);

                   
                    
                        this.camera.stopRecording()
                    // })
         this.props.navigation.goBack();
        }
      }

    takePicture = async () => {
         this.setState({cambtn:false})
               
        if (this.camera) {
            const options = { quality: 0.5 };
            const data = await this.camera.takePictureAsync(options);
            console.log("data", data);


            ImageResizer.createResizedImage(data.uri, 400, 300, 'JPEG', 100)
                .then(response => {
                    RNFetchBlob.fs
                        .readFile(response.path, "base64")
                        .then(data => {

                            // console.log('data', data);
                            // AsyncStorage.removeItem('TakeImage')
                            if (this.state.modal) {

                                var obj = {
                                    type: 'jpg',
                                    base64: data
                                }
                                isImageFLat.push(obj)

                                AsyncStorage.setItem('TakeImage',JSON.stringify(isImageFLat))
                                this.props.navigation.goBack();
                                // setTimeout(() => {
                                //     this.setState({cambtn:true})
                                //     console.log(isImageFLat,'isImageFLat');
                                    
                                // }, 100);

                            }
                            
                        })
                        .catch(err => {
                            Toast.show(err.toString(), Toast.SHORT, Toast.BOTTOM);
                            this.props.navigation.goBack();
                            this.setState({cambtn:true})
                        });
                })

                .catch(err => {
                    Toast.show(err.toString(), Toast.SHORT, Toast.BOTTOM);
                    this.props.navigation.goBack();
                    this.setState({cambtn:true})
                });
         
        }
    }
}


const styles = StyleSheet.create({
                    container: {
                    justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        padding: 10,
        //  margin: 10,
        backgroundColor: '#f1f1f1',
    },
    ModalInsideView: {
                    flexDirection: 'row',

        backgroundColor: "#fff",
        height: 140,
        width: '85%',
        borderRadius: 3,
        borderWidth: 1,
        borderColor: '#fff'

    },
    preview: {
                    flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
});